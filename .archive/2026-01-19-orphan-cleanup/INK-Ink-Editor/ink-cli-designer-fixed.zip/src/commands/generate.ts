import fs from 'fs-extra';
import path from 'path';
import { ScreenSpecSchema } from '../generator/spec.js';
import { emitTsx } from '../generator/emitTsx.js';
import { emitTheme } from '../generator/emitTheme.js';

interface GenerateFlags {
  spec?: string;
  out?: string;
}

export async function runGenerate(flags: GenerateFlags) {
  const specPath = flags.spec ?? 'design-spec.json';
  const outDir = flags.out ?? 'generated';

  if (!fs.existsSync(specPath)) {
    throw new Error(`Spec file not found: ${specPath}`);
  }

  const raw = JSON.parse(fs.readFileSync(specPath, 'utf-8'));
  const parsed = ScreenSpecSchema.safeParse(raw);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `${i.path.join('.') || '<root>'}: ${i.message}`)
      .join('\n');
    throw new Error(`Spec validation failed:\n${issues}`);
  }

  fs.ensureDirSync(outDir);
  fs.ensureDirSync(path.join(outDir, 'ui'));

  fs.writeFileSync(path.join(outDir, 'theme.ts'), emitTheme());
  fs.writeFileSync(path.join(outDir, 'GeneratedScreen.tsx'), emitTsx(parsed.data));

  const frameSrc = fs.readFileSync(new URL('../ui/Frame.tsx', import.meta.url), 'utf-8');
  fs.writeFileSync(path.join(outDir, 'ui', 'Frame.tsx'), frameSrc);
}
