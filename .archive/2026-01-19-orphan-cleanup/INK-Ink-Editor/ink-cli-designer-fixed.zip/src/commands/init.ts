import fs from 'fs-extra';
import path from 'path';
import { emitTheme } from '../generator/emitTheme.js';
import { ScreenSpec } from '../generator/spec.js';

interface InitFlags {
  cols?: number;
  rows?: number;
  out?: string;
}

export async function runInit(flags: InitFlags) {
  const cols = flags.cols ?? 80;
  const rows = flags.rows ?? 24;
  const specPath = flags.out ?? 'design-spec.json';

  const spec: ScreenSpec = {
    meta: {
      name: 'Untitled Layout',
      createdAt: new Date().toISOString(),
      cols,
      rows,
    },
    theme: { preset: 'floyd-neon' },
    nodes: [],
  };

  fs.ensureDirSync(path.dirname(specPath) === '.' ? process.cwd() : path.dirname(specPath));
  fs.writeFileSync(specPath, JSON.stringify(spec, null, 2));

  fs.ensureDirSync('generated/ui');
  fs.writeFileSync('generated/theme.ts', emitTheme());

  // Copy the Frame component into generated/ui so users can drop-in integrate
  const frameSrc = fs.readFileSync(new URL('../ui/Frame.tsx', import.meta.url), 'utf-8');
  fs.writeFileSync('generated/ui/Frame.tsx', frameSrc);
}
